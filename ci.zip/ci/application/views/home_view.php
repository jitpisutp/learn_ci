
<body>
    

   

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h4>::List Product::</h4>
            </div>
            <div class="col-md-4">
                <img src="<?php echo base_url('img/cat.JPG');?>" width="100%">
                <p align="center">
                    my website <br>
                    <a href="" class="btn btn-primary"> more </a>
                </p>
            </div>
            <div class="col-md-4">
                <img src="<?php echo base_url('img/cat.JPG');?>" width="100%">
                <p align="center">
                    my website <br>
                    <a href="" class="btn btn-primary"> more </a>
                </p>
            </div>
            <div class="col-md-4">
                <img src="<?php echo base_url('img/cat.JPG');?>" width="100%">
                <p align="center">
                    my website <br>
                    <a href="" class="btn btn-primary"> more </a>
                </p>
            </div>

        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h4>::List Aeticle::</h4>
            </div>
            <div class="col-md-3">
                <img src="<?php echo base_url('img/cat.JPG');?>" width="100%">
                <p align="center">
                    my website <br>
                    <a href="" class="btn btn-primary"> more </a>
                </p>
            </div>
            <div class="col-md-3">
                <img src="<?php echo base_url('img/cat.JPG');?>" width="100%">
                <p align="center">
                    my website <br>
                    <a href="" class="btn btn-primary"> more </a>
                </p>
            </div>
            <div class="col-md-3">
                <img src="<?php echo base_url('img/cat.JPG');?>" width="100%">
                <p align="center">
                    my website <br>
                    <a href="" class="btn btn-primary"> more </a>
                </p>
            </div>
            <div class="col-md-3">
                <img src="<?php echo base_url('img/cat.JPG');?>" width="100%">
                <p align="center">
                    my website <br>
                    <a href="" class="btn btn-primary"> more </a>
                </p>
            </div>

        </div>
    </div>
    


</body>
</html>
