<div class="container">
        <div class="row">
            <div class="col-md-12">
                <img src="<?php echo base_url('img/banner.jpg');?>" width="100%">
            </div>
        </div>
    </div>