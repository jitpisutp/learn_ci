<div class="container ft">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <p align="center" class="ft">
                    @2018
                </p>
            </div>
        </div>
    </div>